# What's in this patch

- `context/CartContext.tsx` — order type moved here (was local state on the Order screen
  before, which meant it got lost when navigating away — now it survives)
- `components/ProductOptionsModal.tsx` — can now open pre-filled with existing options
  (for editing) instead of always defaulting to the first option of each group
- `components/CartItemCard.tsx` — new. The checkout page's product-style cards
- `app/(tabs)/index.tsx` — Dine In / Take out now navigate to /checkout, but only when
  the cart has at least one item; tapping either with an empty cart just sets the type
- `app/(tabs)/checkout.tsx` — full rebuild: cart items shown as cards (matching the menu's
  look) with a stepper and, for drinks, a small "⋯" button top-right to edit that line's
  specs. Ends with a "+" card that goes back to the Order screen. Empty cart = just the "+"
  card, nothing else.
- `assets/icons/more.png` — new placeholder for the "⋯" edit button, replace with your
  actual overflow-dots icon

Unzip into `C:\dev\ReactN`, merging in (6 files total, none of them delete anything).
`npx expo start --clear` after.

One behavior worth testing deliberately: editing a drink's specs on the checkout page
changes that *entire line's* quantity to the new options — if you had 3 Medium Mattchas
and edit to Large, all 3 become Large (rather than splitting into "2 Medium + 1 Large").
Say so if you actually want per-unit editing instead.
