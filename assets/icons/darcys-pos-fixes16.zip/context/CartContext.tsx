import { createContext, useContext, useReducer, ReactNode, Dispatch } from "react";
import { getUnitPrice, type Product } from "../constants/mockData";

export interface CartItem {
  key: string;
  product: Product;
  quantity: number;
  options?: Record<string, string>;
}

export type OrderType = "Dine In" | "Take out";

interface CartState {
  items: Record<string, CartItem>;
  orderType: OrderType;
}

type CartAction =
  | { type: "ADD"; product: Product; options?: Record<string, string> }
  | { type: "DECREASE"; key: string }
  | { type: "CLEAR" }
  | { type: "EDIT_OPTIONS"; oldKey: string; product: Product; quantity: number; newOptions: Record<string, string> }
  | { type: "SET_ORDER_TYPE"; orderType: OrderType };

// Simple (non-customized) products get a key equal to their plain id. Customized
// products get a key that also encodes their selected options, so different
// variants of the same product are tracked as separate cart lines.
export function makeCartKey(productId: string, options?: Record<string, string>) {
  if (!options) return productId;
  const sorted = Object.keys(options)
    .sort()
    .map((k) => `${k}:${options[k]}`)
    .join("|");
  return `${productId}::${sorted}`;
}

function cartReducer(state: CartState, action: CartAction): CartState {
  switch (action.type) {
    case "ADD": {
      const key = makeCartKey(action.product.id, action.options);
      const existing = state.items[key];
      const quantity = (existing?.quantity || 0) + 1;
      return {
        ...state,
        items: { ...state.items, [key]: { key, product: action.product, quantity, options: action.options } },
      };
    }
    case "DECREASE": {
      const existing = state.items[action.key];
      if (!existing) return state;
      if (existing.quantity <= 1) {
        const { [action.key]: _removed, ...rest } = state.items;
        return { ...state, items: rest };
      }
      return { ...state, items: { ...state.items, [action.key]: { ...existing, quantity: existing.quantity - 1 } } };
    }
    case "EDIT_OPTIONS": {
      // Editing replaces the whole line's options (all of its quantity moves
      // to the new options combination). If that new combination happens to
      // already exist as a separate line, the two merge into one.
      const { [action.oldKey]: _removed, ...rest } = state.items;
      const newKey = makeCartKey(action.product.id, action.newOptions);
      const existingAtNewKey = rest[newKey];
      const mergedQuantity = (existingAtNewKey?.quantity || 0) + action.quantity;
      return {
        ...state,
        items: {
          ...rest,
          [newKey]: { key: newKey, product: action.product, quantity: mergedQuantity, options: action.newOptions },
        },
      };
    }
    case "SET_ORDER_TYPE":
      return { ...state, orderType: action.orderType };
    case "CLEAR":
      return { ...state, items: {}, orderType: "Dine In" };
    default:
      return state;
  }
}

interface CartContextValue {
  items: Record<string, CartItem>;
  list: CartItem[];
  total: number;
  orderType: OrderType;
  dispatch: Dispatch<CartAction>;
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(cartReducer, { items: {}, orderType: "Dine In" });
  const list = Object.values(state.items);
  const total = list.reduce((sum, i) => sum + getUnitPrice(i.product, i.options) * i.quantity, 0);
  return (
    <CartContext.Provider value={{ items: state.items, list, total, orderType: state.orderType, dispatch }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within a CartProvider");
  return ctx;
}
